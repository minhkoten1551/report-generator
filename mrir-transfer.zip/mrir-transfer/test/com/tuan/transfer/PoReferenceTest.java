package com.tuan.transfer;
import java.nio.file.*;
import java.util.*;

public final class PoReferenceTest {
    static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
    interface Operation {void run() throws Exception;}
    static void rejects(Operation run,String message) throws Exception {
        try{run.run();throw new AssertionError("Expected rejection: "+message);}
        catch(IllegalArgumentException expected){check(expected.getMessage().contains(message),expected.getMessage());}
    }
    public static void main(String[] args) throws Exception {
        byte[] bytes=Files.readAllBytes(Path.of(args[0]));
        Workbook source=new Workbook(bytes,"Book1.xlsx");
        Workbook destination=new Workbook(Files.readAllBytes(Path.of(args[1])),"destination.xlsm");
        TransferEngine engine=new TransferEngine();String name="SHIPMENT 1776-160";
        var references=TransferEngine.readPoReferences(source.sheet(name));
        check(references.size()==8,"Eight grouped MRF references expected.");
        check(references.get("JEN2062").equals("116021"),"First group PO.");
        check(references.get("JEN2073").equals("116118"),"Spaces in reference ignored.");
        var items=engine.readItems(source,List.of(name),TransferEngine.DEFAULT_MAPPING);
        check(items.size()==25,"25 source material records expected.");
        for(var item:items) {
            String mrf=item.values().get("J").toString().replaceAll("\\s+","");
            check(item.values().get("C").equals(references.get(mrf)),"Incorrect PO for "+mrf);
        }
        Workbook output=new Workbook(engine.transfer(source,destination,List.of(name),TransferEngine.DEFAULT_MAPPING,false),"output.xlsm");
        check(output.sheet(TransferEngine.TARGET).text(6957,"C").equals("116021"),"First output row PO.");
        check(output.sheet(TransferEngine.TARGET).text(6957,"J").equals("JEN2062"),"Output MRF.");
        Workbook unknown=new Workbook(bytes,"unknown.xlsx");unknown.sheet(name).put(9,"P","JEN9999",9);
        rejects(()->engine.readItems(unknown,List.of(name),TransferEngine.DEFAULT_MAPPING),"no T/U PO reference");
        Workbook conflicting=new Workbook(bytes,"conflict.xlsx");conflicting.sheet(name).put(3,"T","JEN2062",1);conflicting.sheet(name).put(3,"U","999999",1);
        rejects(()->engine.readItems(conflicting,List.of(name),TransferEngine.DEFAULT_MAPPING),"conflicting PO references");
        Workbook incomplete=new Workbook(bytes,"incomplete.xlsx");incomplete.sheet(name).put(1,"U","",1);
        rejects(()->engine.readItems(incomplete,List.of(name),TransferEngine.DEFAULT_MAPPING),"both T (MRF Item) and U (PO No.)");
        Workbook grouped=new Workbook(bytes,"grouped.xlsx");grouped.sheet(name).put(9,"P","JEN2062/2063",9);
        check(engine.readItems(grouped,List.of(name),TransferEngine.DEFAULT_MAPPING).get(0).values().get("C").equals("116021"),"Shorthand same-PO grouping.");
        grouped.sheet(name).put(9,"P","JEN2062,JEN2070",9);
        rejects(()->engine.readItems(grouped,List.of(name),TransferEngine.DEFAULT_MAPPING),"different PO numbers");
        var bypass=new LinkedHashMap<>(TransferEngine.DEFAULT_MAPPING);bypass.put("C","header:O3");
        check(engine.readItems(source,List.of(name),bypass).get(0).values().get("C").toString().contains("116118"),"Explicit header override.");
        System.out.println("PASS: sample's 25 items, grouped references, space normalization, per-item output PO, unknown MRF, missing PO, conflicting assignments, same-PO shorthand, multi-PO rejection and explicit override.");
    }
}
